package project.java.springboot.sockets.console.server;

import lombok.Getter;
import project.java.springboot.models.Post;
import project.java.springboot.sockets.console.posts.PostServiceImpl;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Server {
    @Getter
    //map with username and user's threads parameters
    private final Map<String, UserThread> userThreadMap=new HashMap<>();
    PostServiceImpl postServiceImpl = new PostServiceImpl();
    @Getter
    private int port;

    public Server(){}

    public Server(int port) {
        this.port=port;
    }

    public UserThread getUserThread(String username) {
        return userThreadMap.get(username);
    }

    public Long numberOfPostsFromDB(){
        return postServiceImpl.getPostCount();
    }

    public void addUserThread(String username, UserThread userThread) {
        userThreadMap.put(username, userThread);
        System.out.println("User "+ username +" added to server");
    }

    public void addPost(Post post){
        System.out.println("Post was added");
    }

    public void exec() throws IOException {
        ServerSocket serverSocket= new ServerSocket(this.port);
        checkAndSendEach10MinutesIfNewPostExist();

        System.out.println("Waiting for clients...");

        while (true){

            Socket socket=serverSocket.accept();
            UserThread userThread=new UserThread(socket, this);
            userThread.start();
        }
    }

    private void checkAndSendEach10MinutesIfNewPostExist() {
        TimerTask repeatedTask = new TimerTask() {
            @Override
            public void run() {
                if(!getUserThreadMap().isEmpty()){
                    for(UserThread userThread: getUserThreadMap().values()){
                        refreshPage(userThread.getClientName(), true);
                        System.out.println(userThread.getClientName());
                    }
                }
            }
        };

        Timer timer = new Timer("Check for update new post and send it to users...");

        long period = 1000L * 600L;

        timer.scheduleAtFixedRate(repeatedTask,1000,period);
    }

    public void refreshPage(String username, boolean isItTimer){
        UserThread thread = getUserThread(username);
        Long userId = thread.getUser().getId();
        Long userPostLastId = postServiceImpl.getUpdatedPost(userId);

        if(userPostLastId < numberOfPostsFromDB()){
            if(isItTimer){
                thread.sendMessage("|Each 10 minutes server checks new posts and sends them if they exist|");
            }else
                thread.sendMessage("Page refreshed successfully! New Posts available, check it now:");

            for(Post post: postServiceImpl.getAllPostsFromUserPostId(userPostLastId)){
                getUserThread(username).sendMessage("=======================================" +
                        "\nPost Id: " + post.getId()+
                        "\nContent: "+ post.getContent()+
                        "\nVisibility: "+ post.getVisibility()+
                        "\nComment allowed: "+post.getCommentAllowed()+
                        "\n=======================================");
            }
            if(postServiceImpl.userHasUpdatedPosts(userId)){
                postServiceImpl.updateNewPostList(userId, numberOfPostsFromDB());
            }else
                postServiceImpl.savePostForUser(userId, numberOfPostsFromDB());
        }else if(!isItTimer){
            thread.sendMessage("=======================================\n" +
                    "There is no new posts on server." +
                    "\n=======================================");
        }
    }
}
