package project.java.springboot.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import project.java.springboot.models.Comment;
import project.java.springboot.models.Post;
import project.java.springboot.services.PostService;
import project.java.springboot.services.UserService;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/posts/")
public class PostController {
    @Autowired
    PostService postService;

    @Autowired
    UserService userService;

    @PostMapping("/postAdd")
    public ResponseEntity<?> addPosts(HttpServletRequest request, @RequestBody Post content) {

        return postService.addPost(request, content);
    }

    @PostMapping("/commentAdd")
    public ResponseEntity<?> addComment(HttpServletRequest request, @RequestBody Comment comment,
                                        @RequestParam Long postId){
        return postService.addCommentToPost(request, comment, postId);
    }


}
