package project.java.springboot.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import project.java.springboot.models.User;
import project.java.springboot.repository.UserRepository;
import project.java.springboot.security.jwt.JwtUtils;

import javax.servlet.http.HttpServletRequest;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    @Autowired
    JwtUtils jwtUtils;

    //cycling error not fixed by removing annotation @Autowired, it return null for services
    @Lazy
    @Autowired
    PostService postService;
    //cycling error not fixed by removing annotation @Autowired, it return null for services
    @Lazy
    @Autowired
    FriendService friendService;

    public ResponseEntity<?> getUserInfo(HttpServletRequest request, Long id){
        String status = "all";
        User currentUser = getUserByTokenFromRequest(request);

        User userFromId = userRepository.findUserById(id);
        String visibilityOfUser = userFromId.getRestrictions();

        if(!userRepository.existsByUsername(userFromId.getUsername())){
            return ResponseEntity.notFound().build();
        }

        if(userRepository.existsByUsername(currentUser.getUsername())){
            status = "authorized";
        }

        if(status.equals("authorized") && visibilityOfUser.equals("friends")){
            if(!currentUser.hasFriend(userFromId)){
                return ResponseEntity.badRequest().body("Profile is visible only for friends.");
            }
            status = "friends";
        }

        if(status.equals("all") && !visibilityOfUser.equals("all")){
            return ResponseEntity.badRequest().body("Profile is visible for authorized users.");
        }

        if(currentUser.equals(userFromId)){
            status = "friends";
        }

        String posts = parseResponseEntity(postService.getUserPosts(id, status));
        String friends = parseResponseEntity(friendService.JSON_format(userFromId));

        return ResponseEntity.ok(posts+"\n\n"+friends);
    }

    public User getUserByTokenFromRequest(HttpServletRequest request){
        String token = jwtUtils.parseJwt(request);

        User currentUser = new User();

        if (token != null && jwtUtils.validateJwtToken(token)) {
            String username = jwtUtils.getUserNameFromJwtToken(token);
            if(userRepository.existsByUsername(username)){
                currentUser = userRepository.findByUsername(username).orElseThrow(
                        () -> new UsernameNotFoundException("User Not Found with username: " + username));
            }
        }
        return currentUser;
    }

    public String parseResponseEntity(ResponseEntity<?> entity){
        ResponseEntity<String> responseEntity = new ResponseEntity<>((String) entity.getBody(), HttpStatus.OK);

        return responseEntity.getBody();
    }

    public User findById(Long id){
        return userRepository.findUserById(id);
    }

    public Boolean checkExistsByUsername(User user){
        return userRepository.existsByUsername(user.getUsername());
    }
}
