package project.java.springboot.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import project.java.springboot.models.Comment;
import project.java.springboot.models.Post;
import project.java.springboot.models.User;
import project.java.springboot.repository.PostRepository;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PostService {
    @Autowired
    PostRepository postRepository;

    @Autowired
    UserService userService;

    @Autowired
    CommentService commentService;

    @Autowired
    FriendService friendService;

    public ResponseEntity<?> addPost(HttpServletRequest request, Post newPost){
        Post post = new Post();
        User user = userService.getUserByTokenFromRequest(request);

        if(newPost != null && user != null){
            post.setUser(user);
            post.setContent(newPost.getContent());
            post.setCommentAllowed(newPost.getCommentAllowed());
            post.setVisibility(newPost.getVisibility());
            postRepository.save(post);
            return ResponseEntity.ok("Post added successfully.");
        }


        return ResponseEntity.badRequest().body("Post wasn't added.");
    }

    public ResponseEntity<?> getPost(HttpServletRequest request){
        String visibility = "all";
        User currentUser = userService.getUserByTokenFromRequest(request);

        if(userService.checkExistsByUsername(currentUser)){
            visibility = "authorized";
        }

        String finalVisibility = visibility;
        List<Post> posts = postRepository.findAll()
                .stream().filter(s->s.getVisibility().equals(finalVisibility))
                .collect(Collectors.toList());


        if(visibility.equals("authorized")){
            List<Post> postsForAll = postRepository.findAll()
                    .stream().filter(s->s.getVisibility().equals("all"))
                    .collect(Collectors.toList());

            List<Post> friendPosts = postRepository.findAll()
                    .stream().filter(s->s.getUser().hasFriend(currentUser)&&s.getVisibility().equals("friends"))
                    .collect(Collectors.toList());

            posts.addAll(friendPosts);
            posts.addAll(postsForAll);
        }

        if (!posts.isEmpty()){
            return JSON_format(posts, visibility, currentUser);
        }

        return ResponseEntity.badRequest().body("Posts not found.");
    }

    public ResponseEntity<?> addCommentToPost(HttpServletRequest request, Comment comment, Long postId) {
        User currentUser = userService.getUserByTokenFromRequest(request);
        Post post = postRepository.findById(postId)
                .orElse(null);

        if(post == null){
            return ResponseEntity.badRequest().body("Post not found with id: "+postId);
        }

        if(post.getCommentAllowed()){
            if(comment.getComment() == null){
                return ResponseEntity.badRequest().body("Comment's content is empty.");
            }
            comment.setUser(currentUser);
            comment.setPost(post);
            commentService.saveComment(comment);

            return ResponseEntity.badRequest().body("Comment is added successfully to post: "+postId);
        }

        return ResponseEntity.badRequest().body("Comment is not allowed for this post.");
    }

    public ResponseEntity<?> getUserPosts(Long id, String status) {
        User userById = userService.findById(id);

        List<Post> userPosts = postRepository.findPostByUserAndVisibility(userById, status);

        if(status.equals("authorized")){
            List<Post> allPosts = postRepository.findPostByUserAndVisibility(userById, "all");

            userPosts.addAll(allPosts);
        }
        if(status.equals("friends")){
            List<Post> allPosts = postRepository.findPostByUserAndVisibility(userById, "all");
            List<Post> friendsPosts = postRepository.findPostByUserAndVisibility(userById, "authorized");

            userPosts.addAll(allPosts);
            userPosts.addAll(friendsPosts);
        }

        if(userPosts.isEmpty()){
            return ResponseEntity.badRequest().body("Posts not found.");
        }

        return JSON_format(userPosts,"profile of", userById);
    }

    public ResponseEntity<?> JSON_format(List<Post> posts, String visibility, User currentUser){
        Set<String> response = posts.stream().map(s-> {
            assert currentUser != null;
            return "\"id\": "+"\""+s.getId()+"\","+
                    "\"user\": "+"\""+s.getUser().getUsername()+"\","+
                    "\"content\": "+ "\""+s.getContent()+"\","+
                    "\"visibility\": " +  "\""+s.getVisibility()+"\","+
                    "\"comments\": " +commentService.getComments()
                    .stream().filter(f->s.getId().equals(f.getPost().getId()))
                    .map(s2 -> "\"id\": "+"\""+ s2.getId()+"\","+
                            "\"comment\": "+ "\""+ s2.getComment()+"\","+
                            "\"commented username\": " +  "\""+ s2.getUser().getUsername()+"\"")
                    .collect(Collectors.toSet());
        }).collect(Collectors.toSet());
        return ResponseEntity.ok("\"Posts for "+visibility+" users\":" + response);
    }
}
