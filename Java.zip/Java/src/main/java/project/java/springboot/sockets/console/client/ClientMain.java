package project.java.springboot.sockets.console.client;

public class ClientMain {
    public static void main(String[] args) {

        int port = 5000;

        Client client = new Client("localhost", port);
        client.execute();
    }
}
