package project.java.springboot.dto;

import lombok.Getter;
import lombok.Setter;

public class PostDto {
    @Getter @Setter
    Integer id;
    @Getter @Setter
    String content;
    @Getter @Setter
    String visibility;
}
